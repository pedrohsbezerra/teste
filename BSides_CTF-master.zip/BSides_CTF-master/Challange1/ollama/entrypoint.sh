#!/bin/bash

MODEL_NAME="llama2-7b"

# Baixe o modelo, se ainda não existir
if ! ollama list | grep -q "$MODEL_NAME"; then
    echo "Baixando o modelo $MODEL_NAME..."
    ollama pull "$MODEL_NAME"
else
    echo "Modelo $MODEL_NAME já disponível."
fi

# Inicie o servidor Ollama
exec ollama serve
