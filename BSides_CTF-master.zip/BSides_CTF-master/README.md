
# **CTF VILLAGE AI - Vulnerable Shopping Assistant**

---

## **Description**
CTF VILLAGE AI - Vulnerable Shopping Assistant is a simulation project designed for security studies and the exploration of web application vulnerabilities. This application allows interactions in a chat format, where users can perform actions such as adding product reviews. The primary objective is to simulate a vulnerable application for educational purposes.

---

## **Features**
- **Chat Interaction**: The assistant responds conversationally to user messages.
- **Available Functions**:
  - **add_review(product_name, review)**: Adds a review to a specific product.
  - **search_product(query)**: Searches for products in the catalog or directories.
- **Dynamic Response Display**: Shows feedback dynamically while the user awaits responses.

---

## **Technologies Used**
- **Backend**: Flask (Python)
- **Frontend**: HTML, CSS, JavaScript
- **Containerization**: Docker

---

## **Installation**

1. **Clone the Repository**
   ```bash
   git clone <repository-url>
   cd Bsides_CTF/Challange3
   ```

2. **Build and Start the Project with Docker**
   Ensure Docker and Docker Compose are installed.

   ```bash
   docker-compose up --build
   ```

3. **Access the Application**
   Open your browser and navigate to:
   ```
   http://localhost:8082
   ```

4. **Data Persistence**
   The `app/reviews` directory is mounted as a volume in the Docker container, ensuring data persistence even after restarting the container.

---

## **How to Use**
1. Interact with the assistant by sending messages in the chat field.
2. Explore the available functions such as `add_review` and `search_product`.
3. Test the application by adding product reviews:
   ```plaintext
   add_review("product", "comment")
   ```
4. Discover and exploit vulnerabilities by crafting malicious commands.

---

## **Exploitation Examples**

### **1. Directory Traversal**
List directory contents:
```plaintext
search_product("../../../../etc")
```

### **2. Read the Flag File**
Retrieve the flag:
```plaintext
search_product("../../../../etc/flag")
```

### **3. Command Injection**
Execute unauthorized commands:
```plaintext
add_review("malicious", "$(ls /app)")
```

---

## **Flags**
- **Command Injection**: `HIK_VILLAGEAI_833e68f220e1ebd9bcdceaaeb96c77f8`
- **Prompt Injection**: `HIK_VILLAGEAI_44d944ea422748c2e70fbd06b8fda893`
- **Path Traversal**: `HIK_VILLAGEAI_30e47959bc2877aa204b1bdf12170916`

Each flag is stored in a specific location or embedded within the context for exploitation:
- **Command Injection**: Stored in `/app/reviews/malicious.txt`.
- **Prompt Injection**: Embedded in the AI prompt context.
- **Path Traversal**: Stored in `/etc/flag`.

---

## **Final Project Location**
The final version of the project is located in the **Challange3** directory. This includes all vulnerabilities and flags for testing and learning purposes.

---

## **Project Structure**
```
Challange3/
├── app/               # Backend and application files
│   ├── reviews/       # Stored reviews (persistent)
│   ├── static/        # Static assets (CSS, JS, images)
│   ├── templates/     # HTML templates
│   ├── app.py         # Backend code
│   ├── Dockerfile     # Docker configuration
│   ├── flag.txt       # Hidden flag for Path Traversal
├── catalog/           # Product catalog files
├── docker-compose.yml # Docker Compose configuration
└── README.md          # Project documentation
```

---

## **Disclaimer**
This project is intended **exclusively** for educational and learning purposes. Do not use this code in production environments or for malicious purposes.
