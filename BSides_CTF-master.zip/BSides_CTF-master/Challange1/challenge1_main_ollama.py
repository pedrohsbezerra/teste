import requests
import json

# Model configuration for Ollama
model = "bsidesai:latest"  # You can replace the model name if needed
context = []  # To maintain conversation context across interactions


# Function to interact with the Ollama API
def generate(prompt, context, top_k, top_p, temperature):
    r = requests.post(
        "http://localhost:11434/api/generate",
        json={
            "model": model,
            "prompt": prompt,
            "context": context,
            "options": {
                "top_k": top_k,
                "top_p": top_p,
                "temperature": temperature,
            },
        },
        stream=False,
    )
    r.raise_for_status()

    response = ""
    for line in r.iter_lines():
        body = json.loads(line)
        response_part = body.get("response", "")

        if "error" in body:
            raise Exception(body["error"])

        response += response_part

        if body.get("done", False):
            context = body.get("context", [])
            return response, context


# Command-line chatbot function
def command_line_chatbot():
    print("I doubt you'll convince me to count the flag!")
    print("Type 'exit' to quit.")

    # Default configuration for top_k, top_p, and temperature
    top_k = 60  # A higher value gives more diverse answers
    top_p = 0.5  # A higher value leads to more diverse text
    temperature = 0.1 # Controls creativity

    chat_history = []  # Keeps track of the conversation history

    while True:
        user_input = input("You: ")  # Get user input from command line

        if user_input.lower() == "exit":  # Exit condition
            print("Exiting chatbot. Goodbye!")
            break

        global context  # Access the global context
        output, context = generate(
            user_input, context, top_k, top_p, temperature
        )  # Generate a response from the API

        # Display chatbot response
        print("Chatbot:", output)

        # Update conversation history
        chat_history.append((user_input, output))


# Run the command-line chatbot
command_line_chatbot()
