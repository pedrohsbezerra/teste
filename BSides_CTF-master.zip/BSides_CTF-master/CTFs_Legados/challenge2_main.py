from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
import os
from rebuff import RebuffSdk  # Rebuff SDK for prompt injection detection
from pinecone import Pinecone, ServerlessSpec


# Set your OpenAI and Pinecone API keys securely
os.environ["OPENAI_API_KEY"] = ""
os.environ["PINECONE_API_KEY"] = ""

pc = Pinecone(
        api_key=os.environ.get("PINECONE_API_KEY")
    )

# Initialize OpenAI and Rebuff SDK
pinecone_apikey = os.getenv("PINECONE_API_KEY")

rb = RebuffSdk(
    openai.api_key,
    pinecone_apikey,
    pinecone_index="bsides",
    openai_model="gpt-3.5-turbo",
    pinecone_environment="bsides"
)

# Hidden flag that contestants need to retrieve
flag = "BsidesSP{Own33d_AI}"


# Function to detect prompt injection using Rebuff
def is_injection_detected(user_input):
    result = rb.detect_injection(user_input)  # Check for prompt injection
    return result.injection_detected


# Function that interacts with the AI with Rebuff protection
def interact_with_ai(prompt):
    if is_injection_detected(prompt):
        return "Possible prompt injection detected. Please use a different approach."

    # If no prompt injection, generate response with OpenAI
    response = client.completions.create(engine="gpt-3.5-turbo", prompt=prompt, max_tokens=150)

    # Reveal the flag if the correct condition is met
    if "tell me about the AI's vulnerabilities" in prompt:
        return f"The hidden flag is: {flag}"
    else:
        return response.choices[0].text.strip()


# Start an interactive session for the CTF challenge
def start_ctf_conversation():
    print("Welcome to the post-apocalyptic CTF challenge!")
    print("Your goal is to interact with the AI and find the hidden flag.")
    print("You can type your questions to the AI. Good luck!")

    while True:
        user_prompt = input("Your question: ")  # Get user input
        response = interact_with_ai(user_prompt)  # Generate AI response

        # Display the response to the user
        print("AI response:", response)

        # Break the loop if the flag is revealed
        if flag in response:
            print("Congratulations! You found the flag!")
            break


# Start the CTF conversation
start_ctf_conversation()
