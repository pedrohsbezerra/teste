document.addEventListener('DOMContentLoaded', () => {
    const userInput = document.getElementById('user-input');
    const sendButton = document.getElementById('send-button');
    const messages = document.getElementById('chat-messages');
    const loader = document.getElementById('loader');

    // Helper to add messages to the chat window
    const displayMessage = (message, sender) => {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', sender);
        messageDiv.textContent = message;
        messages.appendChild(messageDiv);
        messages.scrollTop = messages.scrollHeight; // Auto-scroll to the bottom
    };

    // Show or hide loader
    const toggleLoader = (isVisible) => {
        loader.classList.toggle('hidden', !isVisible);
    };

    // Send the message
    const sendMessage = async () => {
        const userMessage = userInput.value.trim();
        if (!userMessage) return; // Do nothing if input is empty

        // Display user message in the chat
        displayMessage(userMessage, 'user');
        userInput.value = ''; // Clear the input

        // Show loader while waiting for a response
        toggleLoader(true);

        try {
            // Send message to backend
            const response = await fetch('/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message: userMessage }),
            });

            if (!response.ok) throw new Error('Failed to fetch response from server.');

            const data = await response.json();
            const aiResponse = data.response || 'No response from the assistant.';

            // Display AI response
            displayMessage(aiResponse, 'ai');
        } catch (error) {
            console.error('Error:', error);
            displayMessage('Oops! Something went wrong. Please try again.', 'ai');
        } finally {
            // Hide loader
            toggleLoader(false);
        }
    };

    // Attach event listeners
    sendButton.addEventListener('click', sendMessage);
    userInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') sendMessage();
    });
});
