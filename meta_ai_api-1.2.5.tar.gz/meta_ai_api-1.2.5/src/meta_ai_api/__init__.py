__version__ = "1.2.5"
from .main import MetaAI  # noqa
